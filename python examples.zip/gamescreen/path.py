import pygame

class Path(object):

    def __init__(self, row, tile, group, g):

        self.row = row
        self.tileSize = tile
        self.game = g
        
    
        
    """
    def display_row(self):

        for i in range(len(self.group)):
            obj = self.group[i]

            if(obj != 0):
    """
                
